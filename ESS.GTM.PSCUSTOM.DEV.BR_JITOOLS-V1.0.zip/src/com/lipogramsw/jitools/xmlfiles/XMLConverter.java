package com.lipogramsw.jitools.xmlfiles;

import com.lipogramsw.jitools.LogHandler;

public class XMLConverter {

	public XMLConverter() 
	{
		LogHandler.getInstance().writeLog("Java Integration Tools for Thomson Reuters - CSV to XML");
	    LogHandler.getInstance().writeLog("http://www.lipogramsw.com/jitools");
	}

}
