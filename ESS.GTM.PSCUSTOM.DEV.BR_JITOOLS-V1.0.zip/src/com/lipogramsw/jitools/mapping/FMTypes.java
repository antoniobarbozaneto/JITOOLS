package com.lipogramsw.jitools.mapping;

public class FMTypes {

	static public String AUTO_UUID = "AUTO_UUID";
	
	
	
	public FMTypes() {

	}

}
