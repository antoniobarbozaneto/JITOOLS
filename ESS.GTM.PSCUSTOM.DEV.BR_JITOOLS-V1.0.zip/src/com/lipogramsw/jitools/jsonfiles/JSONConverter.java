package com.lipogramsw.jitools.jsonfiles;

import com.lipogramsw.jitools.LogHandler;

public class JSONConverter {

	public JSONConverter() 
	{
		LogHandler.getInstance().writeLog("Java Integration Tools for Thomson Reuters - CSV to JSON");
	    LogHandler.getInstance().writeLog("http://www.lipogramsw.com/jitools");
	}
}
